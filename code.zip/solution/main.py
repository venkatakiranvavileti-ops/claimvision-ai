"""
main.py — Multi-Modal Evidence Review Pipeline

Usage:
  python main.py [--dataset-root DATASET_ROOT] [--input INPUT_CSV] [--output OUTPUT_CSV]
                 [--model MODEL] [--concurrency N] [--cache-file CACHE_FILE]

Defaults:
  --dataset-root  .                           (folder that contains dataset/ and images/)
  --input         dataset/claims.csv
  --output        output.csv
  --model         gpt-4o
  --concurrency   3
  --cache-file    .cache_results.json         (avoids reprocessing on re-run)
"""

import argparse
import csv
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

from processor import process_claim


# ---------------------------------------------------------------------------
# CSV loaders
# ---------------------------------------------------------------------------

def load_csv(path: str) -> list[dict]:
    df = pd.read_csv(path, dtype=str).fillna("")
    return df.to_dict(orient="records")


def load_user_history(path: str) -> dict:
    """Returns {user_id: row_dict}."""
    rows = load_csv(path)
    return {str(r.get("user_id", "")).strip(): r for r in rows}


def load_evidence_requirements(path: str) -> dict:
    """Returns {requirement_id: row_dict}."""
    rows = load_csv(path)
    return {str(r.get("requirement_id", "")).strip(): r for r in rows}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def load_cache(cache_file: str) -> dict:
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_cache(cache: dict, cache_file: str) -> None:
    with open(cache_file, "w") as f:
        json.dump(cache, f, indent=2)


def cache_key(row: dict) -> str:
    """Deterministic key from the input fields that affect the result."""
    return json.dumps({
        "user_id": row.get("user_id", ""),
        "image_paths": row.get("image_paths", ""),
        "user_claim": row.get("user_claim", ""),
        "claim_object": row.get("claim_object", ""),
    }, sort_keys=True)


# ---------------------------------------------------------------------------
# Output columns (in order per spec)
# ---------------------------------------------------------------------------

OUTPUT_COLUMNS = [
    "user_id",
    "image_paths",
    "user_claim",
    "claim_object",
    "evidence_standard_met",
    "evidence_standard_met_reason",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "claim_status_justification",
    "supporting_image_ids",
    "valid_image",
    "severity",
]


def merge_row(claim_row: dict, result: dict) -> dict:
    """Merge input fields + model output into a single output row."""
    out = {}
    for col in OUTPUT_COLUMNS:
        if col in result:
            out[col] = result[col]
        else:
            out[col] = claim_row.get(col, "")
    return out


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run_pipeline(
    dataset_root: str,
    input_csv: str,
    output_csv: str,
    user_history_csv: str,
    evidence_req_csv: str,
    model: str,
    concurrency: int,
    cache_file: str,
) -> None:
    print(f"\n{'='*60}")
    print("Multi-Modal Evidence Review Pipeline")
    print(f"{'='*60}")
    print(f"Input:        {input_csv}")
    print(f"Output:       {output_csv}")
    print(f"Dataset root: {dataset_root}")
    print(f"Model:        {model}")
    print(f"Concurrency:  {concurrency}")
    print(f"Cache:        {cache_file}")
    print(f"{'='*60}\n")

    # Load supporting data
    print("Loading supporting data...")
    user_history_map = load_user_history(user_history_csv) if Path(user_history_csv).exists() else {}
    evidence_req_map = load_evidence_requirements(evidence_req_csv) if Path(evidence_req_csv).exists() else {}
    print(f"  User history records: {len(user_history_map)}")
    print(f"  Evidence requirements: {len(evidence_req_map)}")

    # Load claims
    claims = load_csv(input_csv)
    print(f"  Claims to process: {len(claims)}\n")

    # Load cache
    cache = load_cache(cache_file)
    cached_hits = 0

    # Results list (preserves input order)
    results: list[dict | None] = [None] * len(claims)

    # Identify which need processing
    to_process = []  # (index, row)
    for i, row in enumerate(claims):
        ck = cache_key(row)
        if ck in cache:
            results[i] = cache[ck]
            cached_hits += 1
        else:
            to_process.append((i, row))

    print(f"Cache hits: {cached_hits} / {len(claims)}")
    print(f"To process: {len(to_process)}\n")

    if not to_process:
        print("All results from cache — skipping API calls.")
    else:
        start_time = time.time()
        completed = 0

        def worker(args):
            idx, row = args
            user_id = row.get("user_id", "?")
            img_paths = row.get("image_paths", "")
            print(f"  [{idx+1}/{len(claims)}] Processing user={user_id}, images={img_paths[:60]}...")
            res = process_claim(
                claim_row=row,
                user_history_map=user_history_map,
                evidence_req_map=evidence_req_map,
                dataset_root=dataset_root,
                model=model,
            )
            return idx, row, res

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = {executor.submit(worker, item): item for item in to_process}
            for future in as_completed(futures):
                try:
                    idx, row, res = future.result()
                    results[idx] = res
                    ck = cache_key(row)
                    cache[ck] = res
                    completed += 1

                    # Save cache incrementally every 5 results
                    if completed % 5 == 0:
                        save_cache(cache, cache_file)

                    elapsed = time.time() - start_time
                    rate = completed / elapsed if elapsed > 0 else 0
                    remaining = (len(to_process) - completed) / rate if rate > 0 else 0
                    print(f"  Completed {completed}/{len(to_process)} | "
                          f"{rate:.1f}/s | ETA {remaining:.0f}s")
                except Exception as e:
                    idx, row = futures[future]
                    print(f"  FATAL error for row {idx}: {e}")
                    results[idx] = {
                        "evidence_standard_met": False,
                        "evidence_standard_met_reason": str(e),
                        "risk_flags": "manual_review_required",
                        "issue_type": "unknown",
                        "object_part": "unknown",
                        "claim_status": "not_enough_information",
                        "claim_status_justification": str(e),
                        "supporting_image_ids": "none",
                        "valid_image": False,
                        "severity": "unknown",
                    }

        save_cache(cache, cache_file)
        elapsed = time.time() - start_time
        print(f"\nProcessed {len(to_process)} claims in {elapsed:.1f}s "
              f"({elapsed/max(len(to_process),1):.1f}s per claim)\n")

    # Write output CSV
    output_rows = [merge_row(claims[i], results[i]) for i in range(len(claims))]
    df_out = pd.DataFrame(output_rows, columns=OUTPUT_COLUMNS)
    df_out.to_csv(output_csv, index=False)
    print(f"Output written to: {output_csv}")
    print(f"Total rows: {len(df_out)}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Multi-Modal Evidence Review Pipeline")
    parser.add_argument("--dataset-root", default=".", help="Root folder (contains dataset/ and images/)")
    parser.add_argument("--input", default="dataset/claims.csv")
    parser.add_argument("--output", default="output.csv")
    parser.add_argument("--user-history", default="dataset/user_history.csv")
    parser.add_argument("--evidence-req", default="dataset/evidence_requirements.csv")
    parser.add_argument("--model", default="gemini-2.5-flash", help="Gemini model to use")
    parser.add_argument("--concurrency", type=int, default=3)
    parser.add_argument("--cache-file", default=".cache_results.json")
    args = parser.parse_args()

    run_pipeline(
        dataset_root=args.dataset_root,
        input_csv=args.input,
        output_csv=args.output,
        user_history_csv=args.user_history,
        evidence_req_csv=args.evidence_req,
        model=args.model,
        concurrency=args.concurrency,
        cache_file=args.cache_file,
    )


if __name__ == "__main__":
    main()
