"""
Core claim processor: loads images, calls Gemini vision, returns structured output.
Uses Google AI Studio API key (GEMINI_API_KEY).
"""

import os
import base64
import json
import time
import re
from pathlib import Path
from typing import Optional

import google.generativeai as genai
from PIL import Image as PILImage
import io

# ---------------------------------------------------------------------------
# Client setup — Google AI Studio key
# ---------------------------------------------------------------------------

_configured = False

def ensure_configured():
    global _configured
    if _configured:
        return
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "No Gemini API key found. Set GEMINI_API_KEY=<your Google AI Studio key>."
        )
    genai.configure(api_key=api_key)
    _configured = True


def get_model(model_name: str = "gemini-2.5-flash"):
    ensure_configured()
    return genai.GenerativeModel(
        model_name=model_name,
        generation_config=genai.GenerationConfig(
            temperature=0.0,
            max_output_tokens=1024,
        ),
    )


# ---------------------------------------------------------------------------
# Allowed value sets (from spec)
# ---------------------------------------------------------------------------

ALLOWED_CLAIM_STATUS = {"supported", "contradicted", "not_enough_information"}
ALLOWED_ISSUE_TYPE = {
    "dent", "scratch", "crack", "glass_shatter", "broken_part", "missing_part",
    "torn_packaging", "crushed_packaging", "water_damage", "stain", "none", "unknown",
}
ALLOWED_RISK_FLAGS = {
    "none", "blurry_image", "cropped_or_obstructed", "low_light_or_glare", "wrong_angle",
    "wrong_object", "wrong_object_part", "damage_not_visible", "claim_mismatch",
    "possible_manipulation", "non_original_image", "text_instruction_present",
    "user_history_risk", "manual_review_required",
}
ALLOWED_SEVERITY = {"none", "low", "medium", "high", "unknown"}

CAR_PARTS = {
    "front_bumper", "rear_bumper", "door", "hood", "windshield", "side_mirror",
    "headlight", "taillight", "fender", "quarter_panel", "body", "unknown",
}
LAPTOP_PARTS = {"screen", "keyboard", "trackpad", "hinge", "lid", "corner", "port", "base", "body", "unknown"}
PACKAGE_PARTS = {"box", "package_corner", "package_side", "seal", "label", "contents", "item", "unknown"}


def allowed_parts(claim_object: str) -> set:
    mapping = {"car": CAR_PARTS, "laptop": LAPTOP_PARTS, "package": PACKAGE_PARTS}
    return mapping.get(claim_object.lower(), set())


# ---------------------------------------------------------------------------
# Image loading
# ---------------------------------------------------------------------------

def load_pil_image(path: str, dataset_root: str = ".") -> Optional[PILImage.Image]:
    """Load an image as a PIL Image object."""
    full_path = Path(dataset_root) / path
    if not full_path.exists():
        return None
    try:
        img = PILImage.open(full_path)
        img.load()
        # Convert to RGB to ensure JPEG compatibility
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGB")
        elif img.mode == "RGBA":
            bg = PILImage.new("RGB", img.size, (255, 255, 255))
            bg.paste(img, mask=img.split()[3])
            img = bg
        return img
    except Exception as e:
        print(f"  Warning: could not load image {path}: {e}")
        return None


def image_id_from_path(path: str) -> str:
    """Extract image ID (filename without extension) from path."""
    return Path(path).stem


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------

SYSTEM_INSTRUCTION = """You are a professional damage-claim adjuster AI. Your job is to:
1. Analyze submitted images to determine whether damage visible in the photos matches the user's claim.
2. Evaluate image quality and authenticity.
3. Consider user history as a risk signal only — do not override clear visual evidence with it.
4. Apply evidence requirements to determine if the image set is sufficient.

Return a STRICT JSON object with EXACTLY these fields and no others:
{
  "evidence_standard_met": <true|false>,
  "evidence_standard_met_reason": "<short reason>",
  "risk_flags": "<semicolon-separated flags or 'none'>",
  "issue_type": "<one of the allowed issue types>",
  "object_part": "<one of the allowed object parts>",
  "claim_status": "<supported|contradicted|not_enough_information>",
  "claim_status_justification": "<concise image-grounded explanation; mention image IDs>",
  "supporting_image_ids": "<semicolon-separated image IDs or 'none'>",
  "valid_image": <true|false>,
  "severity": "<none|low|medium|high|unknown>"
}

Rules:
- Images are the PRIMARY source of truth.
- claim_status must reflect what the images show, not just what the user says.
- If images are blurry/unusable, set valid_image=false, evidence_standard_met=false.
- Only use risk_flags values from the allowed list.
- severity reflects damage severity visible in images ('none' if no damage visible, 'unknown' if unclear).
- If multiple images: analyze all of them, cite specific image IDs in justification.
- Return ONLY the JSON object — no markdown code fences, no explanation, no extra text."""


def build_prompt(
    claim_row: dict,
    user_history: Optional[dict],
    evidence_requirements: list[dict],
    image_paths: list[str],
) -> str:
    """Build the text portion of the prompt."""
    claim_object = claim_row.get("claim_object", "").lower()
    user_claim = claim_row.get("user_claim", "")
    image_ids = [image_id_from_path(p) for p in image_paths]

    # Evidence requirements
    ev_text = ""
    if evidence_requirements:
        ev_lines = [
            f"- [{r['requirement_id']}] {r['applies_to']}: {r['minimum_image_evidence']}"
            for r in evidence_requirements
        ]
        ev_text = "EVIDENCE REQUIREMENTS:\n" + "\n".join(ev_lines)

    # User history
    hist_text = ""
    if user_history:
        hist_text = (
            f"USER HISTORY (risk context only, do not override clear visual evidence):\n"
            f"  Past claims: {user_history.get('past_claim_count', 'N/A')}, "
            f"Accepted: {user_history.get('accept_claim', 'N/A')}, "
            f"Rejected: {user_history.get('rejected_claim', 'N/A')}, "
            f"Manual reviews: {user_history.get('manual_review_claim', 'N/A')}\n"
            f"  Last 90 days: {user_history.get('last_90_days_claim_count', 'N/A')}\n"
            f"  Flags: {user_history.get('history_flags', 'none')}\n"
            f"  Summary: {user_history.get('history_summary', 'N/A')}"
        )

    parts_list = ", ".join(sorted(allowed_parts(claim_object)))

    return f"""{SYSTEM_INSTRUCTION}

CLAIM DETAILS:
Object type: {claim_object}
Image IDs submitted: {', '.join(image_ids)}
User conversation / claim:
{user_claim}

{ev_text}

{hist_text}

ALLOWED VALUES:
- object_part: {parts_list}
- issue_type: dent, scratch, crack, glass_shatter, broken_part, missing_part, torn_packaging, crushed_packaging, water_damage, stain, none, unknown
- risk_flags: none, blurry_image, cropped_or_obstructed, low_light_or_glare, wrong_angle, wrong_object, wrong_object_part, damage_not_visible, claim_mismatch, possible_manipulation, non_original_image, text_instruction_present, user_history_risk, manual_review_required
- claim_status: supported, contradicted, not_enough_information
- severity: none, low, medium, high, unknown

Analyze all images carefully. The images above are labeled by their image IDs ({', '.join(image_ids)}).
Return ONLY the JSON object."""


# ---------------------------------------------------------------------------
# Response parsing + validation
# ---------------------------------------------------------------------------

def coerce_value(value: str, allowed: set, fallback: str = "unknown") -> str:
    v = str(value).strip().lower()
    if v in allowed:
        return v
    return fallback


def parse_and_validate(raw: str, claim_object: str, image_ids: list[str]) -> dict:
    """Parse model JSON response and validate/coerce all fields."""
    raw = raw.strip()
    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
            except json.JSONDecodeError:
                data = {}
        else:
            data = {}

    result = {}
    result["evidence_standard_met"] = bool(data.get("evidence_standard_met", False))
    result["evidence_standard_met_reason"] = str(data.get("evidence_standard_met_reason", "Unable to determine")).strip()

    raw_flags = str(data.get("risk_flags", "none"))
    flags = [f.strip().lower() for f in raw_flags.split(";") if f.strip()]
    valid_flags = [f for f in flags if f in ALLOWED_RISK_FLAGS]
    result["risk_flags"] = ";".join(valid_flags) if valid_flags else "none"

    result["issue_type"] = coerce_value(data.get("issue_type", "unknown"), ALLOWED_ISSUE_TYPE)
    result["object_part"] = coerce_value(data.get("object_part", "unknown"), allowed_parts(claim_object))
    result["claim_status"] = coerce_value(
        data.get("claim_status", "not_enough_information"),
        ALLOWED_CLAIM_STATUS,
        "not_enough_information",
    )
    result["claim_status_justification"] = str(data.get("claim_status_justification", "No justification provided.")).strip()

    raw_sup = str(data.get("supporting_image_ids", "none"))
    if raw_sup.strip().lower() == "none":
        result["supporting_image_ids"] = "none"
    else:
        sup_ids = [s.strip() for s in raw_sup.split(";") if s.strip()]
        valid_sup = [s for s in sup_ids if s in image_ids]
        result["supporting_image_ids"] = ";".join(valid_sup) if valid_sup else "none"

    result["valid_image"] = bool(data.get("valid_image", True))
    result["severity"] = coerce_value(data.get("severity", "unknown"), ALLOWED_SEVERITY)

    return result


# ---------------------------------------------------------------------------
# Main claim processor
# ---------------------------------------------------------------------------

def process_claim(
    claim_row: dict,
    user_history_map: dict,
    evidence_req_map: dict,
    dataset_root: str = ".",
    model: str = "gemini-2.5-flash",
    max_retries: int = 3,
    retry_delay: float = 3.0,
) -> dict:
    """Process a single claim row. Returns a result dict with all output columns."""
    user_id = str(claim_row.get("user_id", "")).strip()
    raw_paths = str(claim_row.get("image_paths", "")).strip()
    image_paths = [p.strip() for p in raw_paths.split(";") if p.strip()]
    image_ids = [image_id_from_path(p) for p in image_paths]
    claim_object = str(claim_row.get("claim_object", "")).strip().lower()

    user_history = user_history_map.get(user_id)
    ev_reqs = [
        r for r in evidence_req_map.values()
        if r.get("claim_object", "").lower() in (claim_object, "all")
    ]

    prompt_text = build_prompt(
        claim_row=claim_row,
        user_history=user_history,
        evidence_requirements=ev_reqs,
        image_paths=image_paths,
    )

    # Build content parts: images first, then the text prompt
    content_parts = []
    loaded_count = 0
    for path in image_paths:
        img = load_pil_image(path, dataset_root)
        if img:
            content_parts.append(img)
            loaded_count += 1
        else:
            # Can't load image — note it but continue
            content_parts.append(f"[Image '{image_id_from_path(path)}' not found at: {path}]")

    content_parts.append(prompt_text)

    # Call API with retries + exponential backoff
    last_error = None
    gemini_model = get_model(model)

    for attempt in range(max_retries):
        try:
            response = gemini_model.generate_content(content_parts)
            raw_output = response.text or ""
            parsed = parse_and_validate(raw_output, claim_object, image_ids)

            # Post-hoc: apply user-history risk flag (doesn't bias visual analysis)
            if user_history:
                flags_str = str(user_history.get("history_flags", "")).lower()
                hist_summary = str(user_history.get("history_summary", "")).lower()
                rejected = int(user_history.get("rejected_claim", 0) or 0)
                if rejected > 2 or "fraud" in flags_str or "suspicious" in flags_str or "high risk" in hist_summary:
                    existing = set(parsed["risk_flags"].split(";"))
                    existing.discard("none")
                    existing.add("user_history_risk")
                    parsed["risk_flags"] = ";".join(sorted(existing))

            return parsed

        except Exception as e:
            last_error = e
            err_str = str(e).lower()
            # Rate limit: back off longer
            wait = retry_delay * (2 ** attempt)
            if "quota" in err_str or "429" in err_str or "rate" in err_str:
                wait = max(wait, 30)
            print(f"  [attempt {attempt+1}/{max_retries}] error: {e}. Retrying in {wait:.0f}s...")
            time.sleep(wait)

    print(f"  ERROR: all retries failed for user_id={user_id}: {last_error}")
    return {
        "evidence_standard_met": False,
        "evidence_standard_met_reason": f"Processing error: {last_error}",
        "risk_flags": "manual_review_required",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": f"System error during processing: {last_error}",
        "supporting_image_ids": "none",
        "valid_image": False,
        "severity": "unknown",
    }
