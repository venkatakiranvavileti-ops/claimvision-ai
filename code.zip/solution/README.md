# Multi-Modal Evidence Review — Solution

A Python pipeline that uses Gemini 2.5 Flash vision to verify damage claims by analyzing images, user conversations, user history, and evidence requirements.

## Requirements

- Python 3.10+
- **Google AI Studio API key** — get one free at [aistudio.google.com](https://aistudio.google.com/apikey), set as `GEMINI_API_KEY`

## Setup

```bash
pip install -r requirements.txt
export GEMINI_API_KEY=AIza...   # your Google AI Studio key
```

## Dataset Layout Expected

Place dataset files as follows (relative to where you run the scripts):

```
dataset/
  claims.csv
  sample_claims.csv
  user_history.csv
  evidence_requirements.csv
  images/
    test/
      case_001/
        img_1.jpg
        img_2.jpg
      ...
    sample/
      ...
```

Image paths in the CSV must be relative to the working directory (e.g. `images/test/case_001/img_1.jpg`).

## Run on Test Set

```bash
python main.py \
  --input dataset/claims.csv \
  --output output.csv \
  --model gpt-4o \
  --concurrency 3
```

This produces `output.csv` with all required columns.

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--input` | `dataset/claims.csv` | Input CSV |
| `--output` | `output.csv` | Output CSV |
| `--dataset-root` | `.` | Root folder for resolving image paths |
| `--user-history` | `dataset/user_history.csv` | User history CSV |
| `--evidence-req` | `dataset/evidence_requirements.csv` | Evidence requirements CSV |
| `--model` | `gemini-2.5-flash` | Gemini model (e.g. `gemini-2.5-flash`, `gemini-2.5-pro`) |
| `--concurrency` | `3` | Parallel workers |
| `--cache-file` | `.cache_results.json` | Cache file (skip re-processing) |

## Evaluate Against Sample

```bash
# Run pipeline on sample_claims.csv and evaluate accuracy
python evaluate.py \
  --sample dataset/sample_claims.csv \
  --model gemini-2.5-flash \
  --concurrency 3

# If you already have predictions for the sample:
python evaluate.py \
  --sample dataset/sample_claims.csv \
  --predictions my_sample_predictions.csv
```

Results are printed to stdout and written to `evaluation/eval_results.md`.

## Output Columns

| Column | Description |
|--------|-------------|
| `user_id` | User submitting the claim |
| `image_paths` | Semicolon-separated image paths |
| `user_claim` | Original claim conversation |
| `claim_object` | car, laptop, or package |
| `evidence_standard_met` | true/false — image set sufficient to evaluate |
| `evidence_standard_met_reason` | Short reason |
| `risk_flags` | Semicolon-separated risk flags (or `none`) |
| `issue_type` | Visible damage type |
| `object_part` | Relevant part of the object |
| `claim_status` | `supported`, `contradicted`, or `not_enough_information` |
| `claim_status_justification` | Image-grounded explanation |
| `supporting_image_ids` | Image IDs supporting the decision |
| `valid_image` | true/false — image usable for automated review |
| `severity` | none, low, medium, high, unknown |

## Architecture

```
main.py          — CLI entry point, CSV I/O, caching, concurrency
processor.py     — Image loading, prompt construction, GPT-4o call, output parsing/validation
evaluate.py      — Evaluation against sample_claims.csv, accuracy metrics
evaluation/
  evaluation_report.md   — Operational analysis (cost, latency, rate limits)
  eval_results.md        — Auto-generated accuracy results after evaluate.py run
```

## Cost / Performance Summary

| Set | Calls | Approx Cost | Runtime (concurrency=3) |
|-----|-------|-------------|------------------------|
| Sample (~20 rows) | ~20 | ~$0.35 | ~40–60s |
| Test (~100 rows) | ~100 | ~$1.74 | ~4–8 min |

See `evaluation/evaluation_report.md` for full operational analysis.

## Key Design Decisions

1. **One API call per claim** — all images for a claim are batched into a single multi-image message, minimizing round-trips and cost.
2. **Structured JSON output** — the model is instructed to return strictly-formatted JSON; the parser coerces and validates against allowed value sets.
3. **Images are primary truth** — the system prompt explicitly instructs the model to prioritize visual evidence over user claims or history.
4. **Post-hoc risk flags** — user history risk is applied after the model call to avoid biasing the visual analysis.
5. **Disk cache** — processed results are cached by input hash, so re-runs (e.g. after a crash) skip already-completed rows.
6. **Graceful degradation** — if all retries fail for a row, it gets `not_enough_information` + `manual_review_required` rather than crashing the pipeline.
