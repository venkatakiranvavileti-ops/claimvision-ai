"""
evaluate.py — Evaluate system predictions against labeled sample_claims.csv

Usage:
  python evaluate.py [--sample SAMPLE_CSV] [--predictions PREDICTIONS_CSV] [--report REPORT_PATH]

Compares predicted output columns against ground-truth columns in sample_claims.csv.
Prints accuracy per field and writes a summary to the report file.
"""

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.metrics import classification_report, accuracy_score


# Fields to evaluate (must exist in both sample and predictions)
EVAL_FIELDS = [
    "claim_status",
    "issue_type",
    "object_part",
    "severity",
    "evidence_standard_met",
    "valid_image",
]

# Primary field for headline accuracy
PRIMARY_FIELD = "claim_status"


def normalize(val) -> str:
    if pd.isna(val):
        return ""
    return str(val).strip().lower()


def evaluate(sample_csv: str, predictions_csv: str) -> dict:
    sample_df = pd.read_csv(sample_csv, dtype=str).fillna("")
    pred_df = pd.read_csv(predictions_csv, dtype=str).fillna("")

    if len(sample_df) != len(pred_df):
        print(f"WARNING: sample has {len(sample_df)} rows but predictions has {len(pred_df)} rows. Truncating to min.")
        n = min(len(sample_df), len(pred_df))
        sample_df = sample_df.iloc[:n]
        pred_df = pred_df.iloc[:n]

    results = {}
    print(f"\n{'='*60}")
    print("EVALUATION RESULTS")
    print(f"{'='*60}")
    print(f"Total samples: {len(sample_df)}\n")

    for field in EVAL_FIELDS:
        if field not in sample_df.columns:
            print(f"  [{field}] SKIPPED — not in sample CSV")
            continue
        if field not in pred_df.columns:
            print(f"  [{field}] SKIPPED — not in predictions CSV")
            continue

        y_true = [normalize(v) for v in sample_df[field]]
        y_pred = [normalize(v) for v in pred_df[field]]

        acc = accuracy_score(y_true, y_pred)
        results[field] = {
            "accuracy": round(acc, 4),
            "n": len(y_true),
        }

        print(f"  {field:35s} accuracy: {acc:.2%}")

        # Detailed report for primary field
        if field == PRIMARY_FIELD:
            labels = sorted(set(y_true + y_pred))
            report = classification_report(y_true, y_pred, labels=labels, zero_division=0)
            print(f"\n  {PRIMARY_FIELD} classification report:")
            for line in report.strip().split("\n"):
                print(f"    {line}")
            results[field]["classification_report"] = report
            print()

    # Risk flags: exact match accuracy
    if "risk_flags" in sample_df.columns and "risk_flags" in pred_df.columns:
        matches = sum(
            normalize(s) == normalize(p)
            for s, p in zip(sample_df["risk_flags"], pred_df["risk_flags"])
        )
        acc = matches / len(sample_df)
        results["risk_flags_exact"] = {"accuracy": round(acc, 4)}
        print(f"  {'risk_flags (exact)':35s} accuracy: {acc:.2%}")

    # supporting_image_ids: partial match (any overlap)
    if "supporting_image_ids" in sample_df.columns and "supporting_image_ids" in pred_df.columns:
        partial = 0
        for s, p in zip(sample_df["supporting_image_ids"], pred_df["supporting_image_ids"]):
            s_ids = set(normalize(s).split(";")) - {"none", ""}
            p_ids = set(normalize(p).split(";")) - {"none", ""}
            if s_ids == p_ids or (s_ids & p_ids):
                partial += 1
        acc = partial / len(sample_df)
        results["supporting_image_ids_partial"] = {"accuracy": round(acc, 4)}
        print(f"  {'supporting_image_ids (partial)':35s} accuracy: {acc:.2%}")

    print(f"\n{'='*60}")
    headline = results.get(PRIMARY_FIELD, {}).get("accuracy", 0)
    print(f"Headline ({PRIMARY_FIELD}) accuracy: {headline:.2%}")
    print(f"{'='*60}\n")

    return results


def write_report(results: dict, sample_csv: str, predictions_csv: str, report_path: str):
    lines = [
        "# Evaluation Results",
        "",
        f"- Sample file: `{sample_csv}`",
        f"- Predictions file: `{predictions_csv}`",
        "",
        "## Per-Field Accuracy",
        "",
        "| Field | Accuracy |",
        "|-------|---------|",
    ]
    for field, data in results.items():
        acc = data.get("accuracy", "N/A")
        lines.append(f"| {field} | {acc:.2%} |" if isinstance(acc, float) else f"| {field} | {acc} |")

    if PRIMARY_FIELD in results and "classification_report" in results[PRIMARY_FIELD]:
        lines += [
            "",
            f"## {PRIMARY_FIELD} Classification Report",
            "",
            "```",
            results[PRIMARY_FIELD]["classification_report"],
            "```",
        ]

    Path(report_path).parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(lines))
    print(f"Evaluation report written to: {report_path}")


def run_evaluation_with_model(
    sample_csv: str,
    dataset_root: str,
    model: str,
    concurrency: int,
    cache_file: str,
):
    """Run the full pipeline on sample_claims.csv and evaluate against ground truth."""
    import tempfile
    import os
    from main import run_pipeline

    print("\nRunning pipeline on sample_claims.csv for evaluation...")
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as tmp:
        tmp_path = tmp.name

    try:
        run_pipeline(
            dataset_root=dataset_root,
            input_csv=sample_csv,
            output_csv=tmp_path,
            user_history_csv=f"{dataset_root}/dataset/user_history.csv",
            evidence_req_csv=f"{dataset_root}/dataset/evidence_requirements.csv",
            model=model,
            concurrency=concurrency,
            cache_file=cache_file,
        )
        return tmp_path
    except Exception as e:
        print(f"Pipeline run failed: {e}")
        os.unlink(tmp_path)
        raise


def main():
    parser = argparse.ArgumentParser(description="Evaluate predictions against sample_claims.csv")
    parser.add_argument("--sample", default="dataset/sample_claims.csv")
    parser.add_argument("--predictions", default=None,
                        help="Predictions CSV. If not provided, runs the pipeline on sample first.")
    parser.add_argument("--report", default="evaluation/eval_results.md")
    parser.add_argument("--dataset-root", default=".")
    parser.add_argument("--model", default="gemini-2.5-flash")
    parser.add_argument("--concurrency", type=int, default=3)
    parser.add_argument("--cache-file", default=".cache_sample_results.json")
    args = parser.parse_args()

    predictions_csv = args.predictions
    if not predictions_csv:
        predictions_csv = run_evaluation_with_model(
            sample_csv=args.sample,
            dataset_root=args.dataset_root,
            model=args.model,
            concurrency=args.concurrency,
            cache_file=args.cache_file,
        )

    results = evaluate(args.sample, predictions_csv)
    write_report(results, args.sample, predictions_csv, args.report)


if __name__ == "__main__":
    main()
