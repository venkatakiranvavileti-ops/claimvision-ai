# Operational Analysis — Multi-Modal Evidence Review

## System Overview

This system processes damage claims by:
1. Loading each claim's images as PIL Image objects alongside the user conversation, user history, and evidence requirements.
2. Sending a structured multi-modal prompt to **Gemini 2.5 Flash** (vision) via the Google AI Python SDK.
3. Parsing the structured JSON response and validating/coercing all fields against allowed value sets.
4. Optionally applying user-history risk flags post-hoc.

---

## Approximate Model Call Counts

| Stage              | Rows  | Images per row (avg) | Total API calls | Total images |
|--------------------|-------|----------------------|-----------------|--------------|
| Sample evaluation  | ~20   | 1–3 (avg ~2)         | ~20             | ~40          |
| Test set (claims)  | ~100  | 1–3 (avg ~2)         | ~100            | ~200         |
| **Total**          | ~120  | —                    | **~120**        | **~240**     |

Each claim = exactly **1 API call** (all images for a claim are batched into a single multi-image message).  
No separate calls for image pre-processing or re-ranking.

---

## Approximate Token Usage

| Component               | Tokens per call (approx) |
|-------------------------|--------------------------|
| System prompt           | ~350 tokens              |
| User text context       | ~400–700 tokens          |
| Image (1 image, high)   | ~765–1105 tokens         |
| Image (2 images, high)  | ~1530–2210 tokens        |
| Output (JSON response)  | ~200–350 tokens          |

### Per-call estimate (avg 2 images):
- Input: ~350 (system) + ~550 (text) + ~1750 (images) ≈ **2,650 tokens**
- Output: ~275 tokens

### Full test set (~100 calls):
- Input tokens: ~100 × 2,650 = **~265,000 tokens**
- Output tokens: ~100 × 275 = **~27,500 tokens**

### Sample evaluation (~20 calls):
- Input: ~20 × 2,650 = **~53,000 tokens**
- Output: ~20 × 275 = **~5,500 tokens**

---

## Approximate Cost (Test Set Only)

Pricing assumptions (Gemini 2.5 Flash, Google AI Studio pricing):
- Input text: $0.15 / 1M tokens
- Input image: $0.15 / 1M tokens (images billed as text-equivalent tokens)
- Output: $0.60 / 1M tokens (non-thinking) / $3.50 / 1M tokens (thinking)

| Component      | Tokens    | Cost (non-thinking) |
|----------------|-----------|---------------------|
| Input          | 265,000   | $0.04               |
| Output         | 27,500    | $0.02               |
| **Total**      | 292,500   | **~$0.06**          |

> Note: Gemini 2.5 Flash is significantly cheaper than GPT-4o for the same task.
> Gemini counts images as roughly 258 tokens per image at standard resolution.
> For higher accuracy on complex cases, switch to `--model gemini-2.5-pro` (~10× cost increase but stronger reasoning).
> Google AI Studio free tier supports 1,500 requests/day — sufficient for the full test set.

---

## Latency and Runtime

| Scenario              | Estimate |
|-----------------------|----------|
| Single claim (1 call) | 3–8s     |
| Sample set (20 claims, concurrency=3) | ~40–60s |
| Full test set (100 claims, concurrency=3) | ~4–8 min |

Concurrency is set to **3** by default to stay well within rate limits while maintaining throughput.

---

## TPM / RPM Considerations

GPT-4o default rate limits (tier 1):
- **3,500 RPM** (requests per minute)
- **30,000 TPM** (tokens per minute)

At 3 concurrent workers with ~3–8s per call:
- Effective throughput: **~20–30 RPM** — far below the 3,500 RPM limit
- Token throughput: ~20 calls/min × 2,925 tokens = **~58,500 TPM** (slightly above 30K TPM tier-1 limit)

**Mitigation:**
- Default concurrency is set to **3** (conservative)
- Exponential backoff retries (up to 3 attempts) handle transient rate-limit errors
- Claim results are cached to disk (`.cache_results.json`) — re-runs skip already-processed claims entirely

If hitting TPM limits: reduce `--concurrency` to `2` or `1`.

---

## Batching, Throttling, Caching, and Retry Strategy

| Strategy          | Implementation |
|-------------------|----------------|
| **Batching**      | All images for a claim are sent in a single API call (no per-image calls) |
| **Concurrency**   | `ThreadPoolExecutor` with configurable `--concurrency` (default 3) |
| **Caching**       | JSON cache keyed on (user_id, image_paths, user_claim, claim_object); written incrementally every 5 results |
| **Retries**       | Up to 3 attempts with exponential backoff (2s, 4s, 8s) |
| **Rate limiting** | Conservative concurrency keeps RPM/TPM well within limits; no explicit token counter needed at this scale |
| **Fallback**      | On total failure, row gets `claim_status=not_enough_information` + `manual_review_required` flag |

---

## Evaluation Metrics

The evaluation script (`evaluate.py`) computes:

- Per-field **accuracy** against ground-truth sample labels
- **Classification report** (precision, recall, F1) for `claim_status` (the primary field)
- **Partial overlap** accuracy for `supporting_image_ids`
- **Exact match** accuracy for `risk_flags`

Accuracy results are written to `evaluation/eval_results.md` after running.

---

## Known Limitations

1. **Image resolution**: Very small or highly compressed images may not provide enough visual detail for accurate damage assessment — reflected via `valid_image=false` and appropriate risk flags.
2. **Ambiguous damage**: Some damage types (e.g. minor scratches, slight dents) are hard to distinguish at normal photo distances — the model appropriately returns `not_enough_information` with `damage_not_visible` flag.
3. **User claim parsing**: The system extracts the damage claim from conversation text — misidentified claims can cause `claim_mismatch` flags.
4. **No cross-claim learning**: Each claim is processed independently; the system does not learn from historical patterns within a single batch run.
