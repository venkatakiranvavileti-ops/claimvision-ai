#!/usr/bin/env bash
# package_submission.sh — Create code.zip for submission
# Run from the solution/ directory

set -e

cd "$(dirname "$0")"

echo "Packaging solution into ../code.zip..."

zip -r ../code.zip . \
  --exclude "*.pyc" \
  --exclude "__pycache__/*" \
  --exclude ".cache_*.json" \
  --exclude "*.DS_Store"

echo "Done: ../code.zip"
echo ""
echo "Submission checklist:"
echo "  [✓] code.zip — this file"
echo "  [ ] output.csv — run: python main.py"
echo "  [ ] chat_transcript — this conversation"
