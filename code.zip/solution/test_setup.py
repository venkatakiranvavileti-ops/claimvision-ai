"""
test_setup.py — Verify environment is correctly configured before running.
"""
import sys
import os


def check():
    errors = []
    warnings = []

    # Python version
    if sys.version_info < (3, 10):
        errors.append(f"Python 3.10+ required, got {sys.version}")
    else:
        print(f"[OK] Python {sys.version.split()[0]}")

    # Required packages
    packages = ["openai", "pandas", "PIL", "sklearn", "tqdm"]
    for pkg in packages:
        try:
            __import__(pkg)
            print(f"[OK] {pkg}")
        except ImportError:
            errors.append(f"Missing package: {pkg} — run: pip install -r requirements.txt")

    # API key
    has_integration = (
        os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL")
        and os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY")
    )
    has_direct = bool(os.environ.get("OPENAI_API_KEY"))

    if has_integration:
        print("[OK] Replit AI Integration vars found (AI_INTEGRATIONS_OPENAI_BASE_URL + KEY)")
    elif has_direct:
        print("[OK] OPENAI_API_KEY found")
    else:
        errors.append("No OpenAI API key found. Set OPENAI_API_KEY=sk-...")

    # Dataset files
    required_files = [
        "dataset/claims.csv",
        "dataset/user_history.csv",
        "dataset/evidence_requirements.csv",
    ]
    for f in required_files:
        if os.path.exists(f):
            print(f"[OK] {f}")
        else:
            warnings.append(f"Missing: {f} — place dataset files before running")

    sample = "dataset/sample_claims.csv"
    if os.path.exists(sample):
        print(f"[OK] {sample}")
    else:
        warnings.append(f"Missing: {sample} — needed for evaluation")

    print()
    if warnings:
        print("WARNINGS:")
        for w in warnings:
            print(f"  [!] {w}")
        print()

    if errors:
        print("ERRORS:")
        for e in errors:
            print(f"  [x] {e}")
        print()
        sys.exit(1)
    else:
        print("All checks passed. Ready to run.")


if __name__ == "__main__":
    check()
