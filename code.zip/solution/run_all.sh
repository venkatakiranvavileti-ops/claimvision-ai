#!/usr/bin/env bash
# run_all.sh — Full pipeline: evaluate on sample, then process test set
# Usage: bash run_all.sh [--skip-eval]

set -e

SKIP_EVAL=false
for arg in "$@"; do
  [[ "$arg" == "--skip-eval" ]] && SKIP_EVAL=true
done

echo "=============================="
echo "Multi-Modal Evidence Review"
echo "=============================="

# 1. Evaluate on sample (optional)
if [ "$SKIP_EVAL" = false ]; then
  echo ""
  echo "Step 1: Evaluating on sample_claims.csv..."
  python evaluate.py \
    --sample dataset/sample_claims.csv \
    --model gemini-2.5-flash \
    --concurrency 3 \
    --cache-file .cache_sample_results.json
else
  echo "Step 1: Skipping evaluation (--skip-eval)"
fi

# 2. Process full test set
echo ""
echo "Step 2: Processing claims.csv → output.csv..."
python main.py \
  --input dataset/claims.csv \
  --output output.csv \
  --model gemini-2.5-flash \
  --concurrency 3 \
  --cache-file .cache_results.json

echo ""
echo "Done! Output: output.csv"
echo "Evaluation report: evaluation/eval_results.md"
